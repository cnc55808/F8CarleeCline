dpdnPets.onclick = function(s) {
    if (typeof(s) == "object") {
        return;
    }
    alert("Your favorite pet is a " + dpdnPets.selection);
};