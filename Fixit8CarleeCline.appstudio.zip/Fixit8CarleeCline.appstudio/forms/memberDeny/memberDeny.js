memberDeny.onshow=function(){
  lblDeny.value = "You are not a member and have been added, " + inptMember.value
  lblDeny.backgroundColor = "#B22222"
}