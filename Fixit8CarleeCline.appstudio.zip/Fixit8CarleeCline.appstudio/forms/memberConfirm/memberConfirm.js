memberConfirm.onshow=function(){
  lblConfirm.value = "You are a member, " + inptMember.value
  lblConfirm.backgroundColor = "#228B22"
}
