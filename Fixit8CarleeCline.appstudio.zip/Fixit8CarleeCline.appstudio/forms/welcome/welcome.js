/*
welcome.onshow=function(){
  lblMessage.value = "Welcome to the app, account " + accountName
  lblMessage.backgroundColor = "#ADD8E6"
}

*/